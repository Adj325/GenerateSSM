package com.demo.service;

import com.demo.pojo.UserExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserExampleService {

    void addUser(UserExample user);

    void updateUser(UserExample user);

    UserExample getUser(UserExample user);

	UserExample getUserByJSESSIONID(String JSESSIONID);

}
