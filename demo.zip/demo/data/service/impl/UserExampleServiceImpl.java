package com.demo.service.impl;

import com.demo.dao.UserExampleDAO;
import com.demo.pojo.UserExample;
import com.demo.service.UserExampleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userExampleService")
public class UserExampleServiceImpl implements UserExampleService {
    @Autowired
    private UserExampleDAO userExampleDAO;

    // 添加用户，sessionid不能为空
    public void addUser(UserExample user) {
        UserExample tempUser = getUser(user);
        if (tempUser == null) {
            System.out.println("\n不存在，选择添加！\n");
            userExampleDAO.addUser(user);
        } else {
            System.out.println("\n已存在，选择更新！");
            System.out.println("数据库：" + tempUser.toString() + "\n");
            user.setId(tempUser.getId());
            userExampleDAO.updateUser(user);
        }
    }

    public void updateUser(UserExample user) {
        userExampleDAO.updateUser(user);
    }

    public UserExample getUser(UserExample user) {
        return userExampleDAO.getUser(user);
    }

    public UserExample getUserByJSESSIONID(String JSESSIONID) {
        UserExample user = new UserExample();
        user.setSessionid(JSESSIONID);
        return getUser(user);
    }
}
