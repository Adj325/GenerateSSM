package com.demo.dao;

import com.demo.pojo.UserExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserExampleDAO {

    void addUser(@Param("user")UserExample user);

    void updateUser(@Param("user")UserExample user);

    UserExample getUser(@Param("user")UserExample user);
}
