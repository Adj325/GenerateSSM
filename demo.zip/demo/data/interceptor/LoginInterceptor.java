package com.demo.interceptor;

import com.demo.pojo.UserExample;
import com.demo.service.UserExampleService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

// 登陆拦截器需要检测两个sessionid
// request中的sessionid、Cookie中的sessionid
public class LoginInterceptor implements HandlerInterceptor {

    @Autowired
    private UserExampleService userService;

    // 执行Handler方法之前执行
    // 用于身份认证、身份授权
    // 比如身份认证，如果认证通过表示当前用户没有登陆，需要此方法拦截不再向下执行
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {
        String targetUrl = request.getRequestURI();
        // 检测Cookies中的sessionid
        Cookie[] cookieArr = request.getCookies();
        if (cookieArr != null) {
            for (Cookie cookie : cookieArr) {
                String cookieName = cookie.getName();
                String cookieValue = cookie.getValue();
                if (cookieName.equals("JSESSIONID")) {
                    UserExample user = userService.getUserByJSESSIONID(cookieValue);
                    if (user != null) {
                        System.out.println("\nSessionid=" + cookieValue + "已经授权，用户已登陆！");
                        request.getSession().setAttribute("JSESSIONID", cookieValue);
                        return true;
                    }
                }
            }
        }

        // 检测request中的sessionid
        String JSESSIONID = request.getSession().getId();
        UserExample user = userService.getUserByJSESSIONID(JSESSIONID);
        if (user == null) {
            System.out.println("\nSessionid=" + JSESSIONID + "未经授权，提示用户需要登陆！");
            if(targetUrl.contains("/api/"))
                response.sendRedirect("/user/api/isLogin");
            else
                response.sendRedirect("/login.jsp");
            return false;
        } else {
            System.out.println("\nSessionid=" + JSESSIONID + "已经授权，用户已登陆！");
            return true;
        }
    }

    // 进入Handler方法之后，返回modelAndView之前执行
    // 应用场景从modelAndView出发：将公用的模型数据(比如菜单导航)在这里
    // 传到视图，也可以在这里统一指定视图
    public void postHandle(HttpServletRequest request, HttpServletResponse response,
                           Object handler, ModelAndView modelAndView) throws Exception {

    }

    // 执行Handler完成执行此方法
    // 应用场景：统一异常处理，统一日志处理
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex)
            throws Exception {
    }
}
