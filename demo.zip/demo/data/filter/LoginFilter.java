package com.demo.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginFilter implements Filter {

    public void init(FilterConfig arg0) throws ServletException {
        System.out.println("初始化过滤器的方法");
    }

    public void destroy() {
        System.out.println("销毁过滤器方法");
    }

    public void doFilter(ServletRequest req, ServletResponse res,
                         FilterChain chain) throws IOException, ServletException {
        System.out.println("\n\n\n\n\n--------------agfhnghgfsdsfgdsadffgdssfadf==\n\n\n\n\n");

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String path = request.getContextPath();
        String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + path;
        String targetUrl = request.getRequestURI();
        System.out.println(targetUrl+"\n");

        HttpSession session = request.getSession();//获取登录时存在session里面的值
        String name = (String) session.getAttribute("name");
        if (targetUrl.equals("/login.jsp") || name != null ) {
            chain.doFilter(req, res);//如果已登录则直接将请求传递给目标资源
        } else {
            response.sendRedirect(basePath+"/login.jsp");
        }

    }
}
