package com.demo.controller;

import com.demo.pojo.*;
import com.demo.service.UserExampleService;
import com.demo.util.*;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserExampleController {

    private final UserExampleService userExampleService;

    @Autowired
    public UserExampleController(UserExampleService userExampleService) {
        this.userExampleService = userExampleService;
    }

    @RequestMapping(value = "api/test/login")
    @ResponseBody // 微信用户登陆
    public String login(HttpServletRequest request, HttpSession httpSession, @RequestBody Map<String, Object> map) {
        String ckJSESSIONID = "";
        Cookie[] cookieArr = request.getCookies();
        if (cookieArr != null) {
            for (Cookie cookie : cookieArr) {
                String cookieName = cookie.getName();
                String cookieValue = cookie.getValue();
                if (cookieName.equals("JSESSIONID")) {
                    ckJSESSIONID = cookieValue;
                    break;
                }
            }
        }
        String JSESSIONID = httpSession.getId();

        if (JSESSIONID == null || JSESSIONID.equals("")) {
            if (ckJSESSIONID == null || ckJSESSIONID.equals("")) {
                return "找不到JSESSIONID";
            }
            JSESSIONID = ckJSESSIONID;
        }

        // 获取前端用户的 code
        String code = map.get("code").toString();

        System.out.printf("\n本次login中，Sessionid=%s, code=%s\n\n", JSESSIONID, code);

        // 根据appid及secret构造验证url
        String appId = "！！！！！！！！！！";
        String secretId = "！！！！！！！！！！！！";
        String validateUrl = String.format("https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code",
                appId, secretId, code);

        // 访问腾讯验证api，获取session_key及openid
        String responseStr = HTTP.doGet(validateUrl);
        Map responseMap = (Map) JSON.parse(responseStr);
        System.out.println("后端登陆结果：" + JSON.toJSONString(responseMap));

        // 添加用户到数据库
        UserExample user = new UserExample();
        user.setSessionid(JSESSIONID);
        user.setOpenid(responseMap.get("openid").toString());
        //user.setSessionkey(responseMap.get("session_key").toString());

        // 有则添加，无则更新
        userExampleService.addUser(user);

        // 获取数据库中存储的用户信息
        user = userExampleService.getUser(user);
        System.out.println("JSESSIONID:" + user.getSessionid());

        // 返回给前端的结果
        Map frontResultMap = new HashMap();
        frontResultMap.put("JSESSIONID", user.getSessionid());

        return JSON.toJSONString(frontResultMap);
    }

    @RequestMapping(value = "api/test/updateUserByEncryptedData")
    @ResponseBody // 上传加密数据
    public String updateUserByEncryptedData(@CookieValue("JSESSIONID") String JSESSIONID, @RequestBody Map<String, Object> map) {
        Map frontResultMap = new HashMap();
        // 根据JSESSIONID获取用户
        UserExample user = userExampleService.getUserByJSESSIONID(JSESSIONID);
        // JSESSIONID未授权
        if (user == null) {
            frontResultMap.put("code", -1);
            frontResultMap.put("meg", "非法访问");
            return JSON.toJSONString(frontResultMap);
        }

        // 经sessionkey加密后的用户数据
        String encryptedData = map.get("encryptedData").toString();
        String iv = map.get("iv").toString();

        // 使用key解密数据
        JSONObject jsonObject = WXBizDataCrypt.getUserInfo(encryptedData, user.getSessionkey(), iv);
        if (jsonObject == null) {
            frontResultMap.put("code", 1);
            frontResultMap.put("meg", "数据有误");
        } else {
            // 设置信息
            //user.setAvatarUrl(jsonObject.getString("avatarUrl"));

            // 更新用户
            userExampleService.updateUser(user);
            frontResultMap.put("code", 0);
            frontResultMap.put("meg", "上传成功，更新成功！");
        }
        return JSON.toJSONString(frontResultMap);
    }

    @RequestMapping(value = "api/test/isLogin")
    @ResponseBody // 测试用户是否登陆
    public String isLogin(@CookieValue("JSESSIONID") String JSESSIONID) {
        UserExample user = userExampleService.getUserByJSESSIONID(JSESSIONID);
        Map frontMap = new HashMap();
        if (user == null || user.getId() == null) {
            System.out.println("JSESSIONID无效，需要重新登录！");
            frontMap.put("isLogin", false);
            frontMap.put("code", -1);
            frontMap.put("meg", "JSESSIONID无效，需要重新登录！");
            frontMap.put("user", null);
        } else {
            frontMap.put("isLogin", true);
            frontMap.put("code", 1);
            frontMap.put("meg", "已登录！");
            frontMap.put("user", user);
        }
        return JSON.toJSONString(frontMap);
    }

    @RequestMapping(value = "api/test/test")
    @ResponseBody // 测试用户是否登陆
    public String isLogin() {
        Map frontMap = new HashMap();
        frontMap.put("meg", "test");
        return JSON.toJSONString(frontMap);
    }

    @RequestMapping(value = "api/test/updateUser")
    @ResponseBody // 修改用户
    public String updateUser(@CookieValue("JSESSIONID") String JSESSIONID, @RequestBody Map<String, Object> userMap) {
        Map frontResultMap = new HashMap();

        // 根据JSESSIONID获取用户
        UserExample oldUser = userExampleService.getUserByJSESSIONID(JSESSIONID);
        UserExample newUser = new UserExample(userMap);

        // 设置信息-用于myabtis更新
        newUser.setOpenid(oldUser.getOpenid());
        newUser.setId(oldUser.getId());

        System.out.println("旧数据：" + oldUser.toString());
        System.out.println("新数据：" + newUser.toString());

        userExampleService.updateUser(newUser);
        frontResultMap.put("code", 0);
        frontResultMap.put("meg", "更新成功");

        return JSON.toJSONString(frontResultMap);
    }

    @RequestMapping(value = "api/test/getUser")
    @ResponseBody // 获取用户
    public String getUser(@CookieValue("JSESSIONID") String JSESSIONID) {
        // 根据JSESSIONID获取用户
        UserExample userExample = userExampleService.getUserByJSESSIONID(JSESSIONID);
        return JSON.toJSONString(userExample);
    }

}

